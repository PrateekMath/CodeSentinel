const API_URL = process.env.API_URL;
const value = "normal application data";
function getValue() { return value; }
