const crypto = require("crypto");
function fingerprint(value) { return crypto.createHash("md5").update(value).digest("hex"); }
