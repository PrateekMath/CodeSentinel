const axios = require("axios");
async function fetchUrl(req) { return axios.get(req.query.url); }
