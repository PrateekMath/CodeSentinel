function renderProfile(req, res) { const name = req.query.name; res.send("<h1>" + name + "</h1>"); }
