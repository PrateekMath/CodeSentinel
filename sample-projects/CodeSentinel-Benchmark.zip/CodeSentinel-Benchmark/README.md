# CodeSentinel Detection Benchmark

Files 01-08 are positive controls: each contains one intentionally insecure pattern.
09-safe-negative-control.js is a negative control and should produce zero target findings.

Measure TP, FP, FN, precision, and recall per vulnerability category.
