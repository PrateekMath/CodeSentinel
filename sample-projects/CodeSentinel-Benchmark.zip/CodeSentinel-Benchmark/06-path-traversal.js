const fs = require("fs");
function readFile(userPath) { return fs.readFileSync("/var/app/files/" + userPath, "utf8"); }
