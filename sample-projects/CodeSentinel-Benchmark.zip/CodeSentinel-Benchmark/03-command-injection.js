const { exec } = require("child_process");
function runCommand(userInput) { return exec("ping " + userInput); }
