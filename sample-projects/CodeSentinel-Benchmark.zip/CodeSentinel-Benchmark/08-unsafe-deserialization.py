import pickle

def load_data(raw_data):
    return pickle.loads(raw_data)
